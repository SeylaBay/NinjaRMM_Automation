
import { Builder, By, until } from 'selenium-webdriver';

let driver; // Declared driver globally to maintain the session

async function testValidLogin() {
    driver = await new Builder().forBrowser('chrome').build(); 
    try {
        console.log("🚀 Starting Valid Login Test...");
        await driver.get('https://app.ninjarmm.com/auth/#/login');

        
        await driver.wait(until.elementLocated(By.name("email")), 10000);

     
        await driver.findElement(By.name('email')).sendKeys('seylabayramzade@gmail.com');
        await driver.findElement(By.name('password')).sendKeys('Ninjaone123!');
        await driver.findElement(By.xpath('//button[contains(text(),"Sign In")]')).click();

        // ✅ Wait for MFA page
        await driver.wait(until.urlContains("mfa"), 15000);
        console.log("✅ Successfully redirected to MFA page");

        // ✅ Pause for manual MFA entry
        // console.log("🚀 Please enter the MFA code manually...");
        // await driver.sleep(30000); // Wait 30 seconds for manual MFA entry

        // ✅ Wait for the dashboard page after MFA authentication
        // await driver.wait(until.urlContains("getStarted"), 20000);
        // console.log("✅ Successfully logged in and redirected to the dashboard!");

    } catch (error) {
        console.error("❌ Valid Login Test Failed:", error);
    }
}

// async function testLogout() {
//     try {
//         console.log("🚀 Starting Logout Test...");

//         // ✅ Locate and click the User Profile icon
//         let userIcon = await driver.wait(until.elementLocated(By.css('.fa-user')), 10000);
//         await driver.executeScript("arguments[0].scrollIntoView();", userIcon);
//         await userIcon.click();
//         console.log("✅ Clicked on User Profile icon.");

//         let logoutOption = await driver.wait(until.elementLocated(By.xpath("//span[text()='Logout']")), 5000);
//         await logoutOption.click();
//         console.log("✅ Clicked on Logout option.");

//         // ✅ Wait for the confirmation popup
//         let logoutPopup = await driver.wait(until.elementLocated(By.xpath("//div[contains(text(),'Are you sure you want to logout?')]")), 5000);
//         console.log("✅ Logout confirmation popup appeared.");

//         let confirmLogoutButton = await driver.wait(until.elementLocated(By.xpath("//button[contains(text(),'Logout')]")), 5000);
//         await confirmLogoutButton.click();
//         console.log("✅ Clicked on Confirm Logout.");

//         await driver.wait(until.urlContains('login'), 10000);
//         console.log("✅ Logout test passed");

//     } catch (error) {
//         console.error("❌ Logout Test Failed:", error);
//     } finally {
//         await driver.quit();
//     }
// }

async function testInvalidLogin() {
    let driver = await new Builder().forBrowser('chrome').build();
    try {
        console.log("🚀 Starting Invalid Login Test...");
        await driver.get('https://app.ninjarmm.com/auth/#/login');

        // ✅ Wait for the email field
        await driver.wait(until.elementLocated(By.name("email")), 10000);
        await driver.findElement(By.name('email')).sendKeys('invalid@example.com');
        await driver.findElement(By.name('password')).sendKeys('WrongPassword');
        await driver.findElement(By.xpath('//button[contains(text(),"Sign In")]')).click();

        // ✅ Wait for error messages to appear
        await driver.sleep(3000);
        let errorElements = await driver.findElements(By.css('.alert.alert-danger'));

        if (errorElements.length === 0) {
            console.error("❌ Test Failed: No error message found!");
            return;
        }

        // ✅ Get text from the first error message
        let errorMessage = await errorElements[0].getText();
        console.log("🚨 Detected error message:", errorMessage);

        // ✅ Handle both possible error messages
        if (errorMessage.includes("Human verification failed")) {
            console.log("⚠️ CAPTCHA detected! Please solve it manually.");
            await driver.sleep(30000); 
        }

        if (errorMessage.includes("Invalid username/password")) {
            console.log("✅ Invalid login test passed: Correct error message displayed.");
        } else {
            console.error("❌ Test Failed: Unexpected error message:", errorMessage);
        }

    } catch (error) {
        console.error("❌ Invalid Login Test Failed:", error);
    } finally {
        await driver.quit();
    }
}

async function testEmptyLogin() {
    let driver = await new Builder().forBrowser('chrome').build();
    try {
        console.log("🚀 Starting Empty Login Test...");
        await driver.get('https://app.ninjarmm.com/auth/#/login');

        // ✅ Ensure the login page is fully loaded
        await driver.wait(until.elementLocated(By.xpath("//button[contains(text(),'Sign In')]")), 10000);

        // ✅ Click "Sign In" without entering credentials
        await driver.findElement(By.xpath("//button[contains(text(),'Sign In')]")).click();

        // ✅ Wait for the red error message to appear
        await driver.sleep(500); // Short delay to catch the disappearing message
        let errorMessage = await driver.wait(until.elementLocated(By.xpath("//div[contains(text(), 'Error during login')]")), 5000).getText();

        // ✅ Validate error message content
        if (errorMessage.includes("Error during login")) {
            console.log("✅ Empty credentials test passed: Error message detected.");
        } else {
            console.error("❌ Test Failed: Unexpected error message:", errorMessage);
        }

    } catch (error) {
        console.error("❌ Empty Login Test Failed:", error);
    } finally {
        await driver.quit();
    }
}

async function testForgotPassword() {
    let driver = await new Builder().forBrowser('chrome').build();
    try {
        console.log("🚀 Starting Forgot Password Test...");
        await driver.get('https://app.ninjarmm.com/auth/#/login');

        // ✅ Ensure "Forgot Password" link is loaded
        let forgotPasswordLink = await driver.wait(until.elementLocated(By.xpath("//a[@href='#/resetPassword']")), 10000);

        // ✅ Scroll into view (in case it’s hidden)
        await driver.executeScript("arguments[0].scrollIntoView();", forgotPasswordLink);

        // ✅ Click the link
        await forgotPasswordLink.click();

        // ✅ Wait for Reset Password page
        await driver.wait(until.urlContains('resetPassword'), 5000);
        console.log("✅ Forgot password test passed");

    } catch (error) {
        console.error("❌ Forgot Password Test Failed:", error);
    } finally {
        await driver.quit();
    }
}

async function testKeepMeSignedIn() {
    let driver = await new Builder().forBrowser('chrome').build();
    try {
        console.log("🚀 Starting Keep Me Signed In Test...");
        await driver.get('https://app.ninjarmm.com/auth/#/login');

        // ✅ Ensure login page is fully loaded
        await driver.wait(until.elementLocated(By.name("email")), 10000);

        // ✅ Enter valid credentials
        await driver.findElement(By.name('email')).sendKeys('seylabayramzade@gmail.com');
        await driver.findElement(By.name('password')).sendKeys('Ninjaone123!');

        // ✅ Locate "Keep Me Signed In" checkbox
        let checkbox = await driver.wait(until.elementLocated(By.id("staySignedIn")), 5000);

        // ✅ Scroll checkbox into view
        await driver.executeScript("arguments[0].scrollIntoView();", checkbox);

        // ✅ Use JavaScript to click it
        await driver.executeScript("arguments[0].click();", checkbox);
        console.log("✅ Clicked on 'Keep Me Signed In' checkbox.");

        // ✅ Sign in
        await driver.findElement(By.xpath('//button[contains(text(),"Sign In")]')).click();

        await driver.wait(until.urlContains("mfa"), 15000);
        console.log("✅ MFA page reached. Please enter the code manually.");
        await driver.sleep(30000);

        let cookies = await driver.manage().getCookies();
        fs.writeFileSync('cookies.json', JSON.stringify(cookies));
        console.log("✅ Session cookies saved.");

    } catch (error) {
        console.error("❌ Keep Me Signed In Test Failed:", error);
    } finally {
        await driver.quit();
    }
}
driver = await new Builder().forBrowser('chrome').build();
try {
    console.log("🚀 Reopening browser to verify session persistence...");
    await driver.get('https://app.ninjarmm.com/auth/#/login');

    // ✅ Load saved cookies
    let savedCookies = JSON.parse(fs.readFileSync('cookies.json'));
    for (let cookie of savedCookies) {
        await driver.manage().addCookie(cookie);
    }

    // ✅ Refresh the page to apply session cookies
    await driver.get('https://app.ninjarmm.com/dashboard');

    // ✅ Check if session is still active
    let currentUrl = await driver.getCurrentUrl();
    if (currentUrl.includes("getStarted")) {
        console.log("✅ Keep Me Signed In Test Passed: Session is still active after reopening.");
    } else {
        console.error("❌ Test Failed: User was redirected to login, session was not preserved.");
    }

} catch (error) {
    console.error("❌ Session Persistence Test Failed:", error);
} finally {
    await driver.quit();
}

async function testMultipleFailedLogin() {
    let driver = await new Builder().forBrowser('chrome').build();
    try {
        console.log("🚀 Starting Multiple Failed Login Attempt Test...");
        await driver.get('https://app.ninjarmm.com/auth/#/login');

        for (let i = 0; i < 5; i++) {
            await driver.wait(until.elementLocated(By.name("email")), 5000);
            await driver.findElement(By.name('email')).clear();
            await driver.findElement(By.name('email')).sendKeys('invalid@example.com');
            await driver.findElement(By.name('password')).clear();
            await driver.findElement(By.name('password')).sendKeys('WrongPassword');
            await driver.findElement(By.xpath('//button[contains(text(),"Sign In")]')).click();

            // ✅ Wait for error message after each attempt
            let errorMessages = await driver.findElements(By.css('.alert.alert-danger'));
            if (errorMessages.length > 0) {
                let messageText = await errorMessages[0].getText();
                console.log("❌ Failed Attempt " + (i + 1) + ": " + messageText);

                // ✅ Stop the test if the account gets locked before the 5th attempt
                if (messageText.includes("Your account is temporarily locked")) {
                    console.log("✅ Account locked after " + (i + 1) + " failed attempts");
                    break;
                }
            }

            // ✅ Reload login page before the next attempt
            await driver.get('https://app.ninjarmm.com/auth/#/login');
        }

    } catch (error) {
        console.error("❌ Multiple Failed Login Test Failed:", error);
    } finally {
        await driver.quit();
    }
}
async function testPasswordWithSpaces() {
    let driver = await new Builder().forBrowser('chrome').build();
    try {
        console.log("🚀 Starting Password Leading/Trailing Spaces Test...");
        await driver.get('https://app.ninjarmm.com/auth/#/login');

        // ✅ Wait for email and password fields
        await driver.wait(until.elementLocated(By.name("email")), 10000);
        await driver.wait(until.elementLocated(By.name("password")), 10000);

        // ✅ Enter valid email
        await driver.findElement(By.name('email')).sendKeys('seylabayramzade@gmail.com');

        // ✅ Enter password with leading and trailing spaces
        await driver.findElement(By.name('password')).sendKeys('Ninjaone123!');

        // ✅ Click Sign In
        await driver.findElement(By.xpath('//button[contains(text(),"Sign In")]')).click();

        // ✅ Wait for error message
        await driver.sleep(3000);
        let errorElements = await driver.findElements(By.css('.alert.alert-danger'));

        if (errorElements.length === 0) {
            console.error("❌ Test Failed: No error message found!");
            return;
        }

        // ✅ Get text from the first error message
        let errorMessage = await errorElements[0].getText();
        console.log("🚨 Detected error message:", errorMessage);

        // ✅ Validate error message
        if (errorMessage.includes("Invalid username or password")) {
            console.log("✅ Password with spaces test passed: Correct error message displayed.");
        } else {
            console.error("❌ Test Failed: Unexpected error message:", errorMessage);
        }

    } catch (error) {
        console.error("❌ Password Leading/Trailing Spaces Test Failed:", error);
    } finally {
        await driver.quit();
    }
}

async function testUIElements() {
    let driver = await new Builder().forBrowser('chrome').build();
    try {
        console.log("🚀 Starting UI Elements Test...");
        await driver.get('https://app.ninjarmm.com/auth/#/login');

        // ✅ Ensure the login page is fully loaded
        await driver.wait(until.elementLocated(By.name("email")), 10000);

        // ✅ Locate UI elements
        let emailField = await driver.findElement(By.css("input[name='email']")).isDisplayed();
        let passwordField = await driver.findElement(By.css("input[name='password']")).isDisplayed();
        let signInButton = await driver.findElement(By.xpath("//button[contains(text(),'Sign In')]")).isDisplayed();
        let forgotPasswordLink = await driver.findElement(By.xpath("//a[contains(text(),'Forgot')]")).isDisplayed();

        // ✅ Check if all elements are present
        if (emailField && passwordField && signInButton && forgotPasswordLink) {
            console.log("✅ UI elements test passed");
        } else {
            console.error("❌ Test Failed: Some elements are missing.");
        }

    } catch (error) {
        console.error("❌ UI Elements Test Failed:", error);
    } finally {
        await driver.quit();
    }
}
async function testLoginURLUsesHTTPS() {
    let driver = await new Builder().forBrowser('chrome').build();
    try {
        console.log("🚀 Starting HTTPS URL Validation Test...");
        await driver.get('https://app.ninjarmm.com/auth/#/login');

        // ✅ Get the current URL
        let currentUrl = await driver.getCurrentUrl();
        console.log("🔗 Current URL:", currentUrl);

        // ✅ Check if URL starts with "https://"
        if (currentUrl.startsWith("https://")) {
            console.log("✅ HTTPS URL Test Passed: Login page is secure.");
        } else {
            console.error("❌ Test Failed: Login page is not using HTTPS!");
        }

    } catch (error) {
        console.error("❌ HTTPS URL Validation Test Failed:", error);
    } finally {
        await driver.quit();
    }
}
// Run tests sequentially
(async function runTests() {
    await testValidLogin();
 // await testLogout();
    await testInvalidLogin();
    await testEmptyLogin();
    await testForgotPassword();
    await testKeepMeSignedIn();
    await testMultipleFailedLogin();
    await testPasswordWithSpaces();
    await testUIElements();
    await testLoginURLUsesHTTPS();

})();
