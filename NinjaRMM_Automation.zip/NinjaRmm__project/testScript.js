import { Builder, By, until } from 'selenium-webdriver';
import * as chrome from 'selenium-webdriver/chrome.js';

class BaseTest {
    constructor() {
        let options = new chrome.Options();
        options.addArguments('--headless'); // ✅ Enable headless mode (No UI)

        // ✅ Initialize WebDriver with headless options
        this.driver = new Builder()
            .forBrowser('chrome')
            .setChromeOptions(options)
            .build();
    }

    async openLoginPage() {
        console.log("🚀 Opening Login Page...");
        await this.driver.get('https://app.ninjarmm.com/auth/#/login');
        await this.driver.wait(until.elementLocated(By.name("email")), 10000);
    }

    async enterCredentials(email, password) {
        await this.driver.findElement(By.name('email')).sendKeys(email);
        await this.driver.findElement(By.name('password')).sendKeys(password);
    }

    async clickSignIn() {
        await this.driver.findElement(By.xpath('//button[contains(text(),"Sign In")]')).click();
    }

    async waitForErrorMessage() {
        await this.driver.sleep(2000);
        let errorElements = await this.driver.findElements(By.css('.alert.alert-danger'));
        return errorElements.length > 0 ? await errorElements[0].getText() : null;
    }

    async close() {
        await this.driver.quit();
    }
}

class LoginTest extends BaseTest {
    async testValidLogin() {
        try {
            await this.openLoginPage();
            await this.enterCredentials('seylabayramzade@gmail.com', 'Ninjaone123!');
            await this.clickSignIn();
            await this.driver.wait(until.urlContains("mfa"), 15000);
            console.log("✅ Successfully redirected to MFA page.");
        } catch (error) {
            console.error("❌ Valid Login Test Failed:", error);
        }
    }

    async testInvalidLogin() {
        try {
            await this.openLoginPage();
            await this.enterCredentials('invalid@example.com', 'WrongPassword');
            await this.clickSignIn();
            let errorMessage = await this.waitForErrorMessage();
            console.log("🚨 Detected error:", errorMessage);
        } catch (error) {
            console.error("❌ Invalid Login Test Failed:", error);
        }
    }

    async testEmptyLogin() {
        try {
            await this.openLoginPage();
            await this.clickSignIn();
            let errorMessage = await this.waitForErrorMessage();
            console.log("🚨 Detected error:", errorMessage);
        } catch (error) {
            console.error("❌ Empty Login Test Failed:", error);
        }
    }

    async testKeepMeSignedIn() {
        try {
            await this.openLoginPage();
            await this.enterCredentials('seylabayramzade@gmail.com', 'Ninjaone123!');
            let checkbox = await this.driver.findElement(By.id("staySignedIn"));
            await this.driver.executeScript("arguments[0].click();", checkbox);
            await this.clickSignIn();
            await this.driver.wait(until.urlContains("mfa"), 15000);
            console.log("✅ Keep Me Signed In Test Passed.");
        } catch (error) {
            console.error("❌ Keep Me Signed In Test Failed:", error);
        }
    }
}

class UIValidationTest extends BaseTest {
    async testUIElements() {
        try {
            await this.openLoginPage();
            let emailField = await this.driver.findElement(By.name("email")).isDisplayed();
            let passwordField = await this.driver.findElement(By.name("password")).isDisplayed();
            let signInButton = await this.driver.findElement(By.xpath("//button[contains(text(),'Sign In')]")).isDisplayed();
            let forgotPasswordLink = await this.driver.findElement(By.xpath("//a[contains(text(),'Forgot')]")).isDisplayed();
            console.log("✅ UI Elements Test Passed:", emailField, passwordField, signInButton, forgotPasswordLink);
        } catch (error) {
            console.error("❌ UI Elements Test Failed:", error);
        }
    }

    async testLoginURLUsesHTTPS() {
        try {
            await this.openLoginPage();
            let currentUrl = await this.driver.getCurrentUrl();
            if (currentUrl.startsWith("https://")) {
                console.log("✅ HTTPS URL Test Passed.");
            } else {
                console.error("❌ HTTPS URL Test Failed: Not using HTTPS.");
            }
        } catch (error) {
            console.error("❌ HTTPS URL Test Failed:", error);
        }
    }
}

// ✅ Run All Tests Sequentially
(async function runTests() {
    let loginTest = new LoginTest();
    let uiTest = new UIValidationTest();

    await loginTest.testValidLogin();
    await loginTest.testInvalidLogin();
    await loginTest.testEmptyLogin();
    await loginTest.testKeepMeSignedIn();
    await uiTest.testUIElements();
    await uiTest.testLoginURLUsesHTTPS();

    // ✅ Close the browser after all tests
    await loginTest.close();
})();
